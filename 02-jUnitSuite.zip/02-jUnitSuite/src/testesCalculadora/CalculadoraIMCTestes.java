package testesCalculadora;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fontesCalculadora.CalculadoraIMC;

class CalculadoraIMCTeste {
	CalculadoraIMC calcIMC = new CalculadoraIMC();

	@Test
	public void testeCalculoImcPeso100Altura2Metros() {
		double esp = 25.0;
		double real = calcIMC.calculaIMC(100, 2);
		
		assertEquals(esp, real, 0);
	}

}
