package testesCalculadora;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite // fiz bosta arrumar pro jUnit 4 dps
@SelectClasses({ CalculadoraAritmeticaTeste.class, CalculadoraIMCTeste.class })
public class CalculadoraRelease01 {

}
