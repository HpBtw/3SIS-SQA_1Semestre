package testesCalculadora;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import fontesCalculadora.CalculadoraAritmetica;

public class CalculadoraAritmeticaTeste {
	
	static private int contador = 1;
	private String nomeTeste;
	private double esp = 0; // resultado esperado
	private double real = 0; // resultado real
	
	@Before
	public void abrirTeste() {
		System.out.println("Iniciando o teste número: " + contador);
	}
	
	@After
	public void finalizarTeste() {
		System.out.println("Finalizando o teste número: " + contador++ + " - " + nomeTeste);
		System.out.println("=======");
	}
	
	CalculadoraAritmetica calc = new CalculadoraAritmetica();
	
	@Test
	public void testeSomar2com5() {
		nomeTeste = "Somar 2 com 5";
		
		esp = 7;
		// CalculadoraAritmetica calc = new CalculadoraAritmetica();
		real = calc.soma(2, 5);
		
		assertEquals(esp, real, 0.1); // compara as 2 variaveis
	}
	
	@Test
	public void testeSomar3com5() {		
		nomeTeste = "Somar 3 com 5";

		esp = 8;
		// CalculadoraAritmetica calc = new CalculadoraAritmetica();
		real = calc.soma(3, 5);
		
		assertEquals(esp, real, 0.1); // compara as 2 variaveis
	}
	
	@Test
	public void testeSubtrair4de6() {
		nomeTeste = "Subtrair 4 de 6";

		esp = 2;
		// CalculadoraAritmetica calc = new CalculadoraAritmetica();
		real = calc.subtrai(4, 6);
		
		assertEquals(esp, real, 0.1);
	}
	
	@Test
	public void testeSubtrair5de10() {
		nomeTeste = "Subtrair 5 de 10";
		
		esp = 5;
		real = calc.subtrai(5, 10);
		
		assertEquals(esp, real, 1);
	}
	
	@Test
	public void testeMultiplicar3por3() {
		nomeTeste = "Multiplicar 3 por 3";
		
		esp = 9;
		real = calc.multiplica(3, 3);
		
		assertEquals(esp, real, 1);
	}
	
	@Test
	public void testeDividir10por3() {
		nomeTeste = "Dividir 10 por 3";
		
		esp = 3.333;
		real = calc.divide(10, 3);
		
		assertEquals(esp, real, 0.001);
	}

}
