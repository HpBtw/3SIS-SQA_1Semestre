package fontesCalculadora;

public class CalculadoraIMC {
	
	public double calculaIMC (double peso, double altura) {
		CalculadoraAritmetica calc = new CalculadoraAritmetica();
		
		double alturaAoQuadrado = calc.multiplica(altura, altura);
		double imcCalculado = calc.divide(peso, alturaAoQuadrado);
		
		return imcCalculado;
		
	}

}
