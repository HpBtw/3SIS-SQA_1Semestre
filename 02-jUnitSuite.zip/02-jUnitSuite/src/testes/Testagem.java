package testes;

import java.util.Scanner;

import fontesCalculadora.CalculadoraAritmetica;

public class Testagem {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		CalculadoraAritmetica calc = new CalculadoraAritmetica();
		
		Integer x = 0;
		Integer y = 0;
		
		try {
			System.out.print("\nInforme o valor de x: ");
			x = kb.nextInt();
			System.out.print("Informe o valor de y: ");
			y = kb.nextInt();
		} catch (Exception e) {
			System.out.println("Erro ao informar os valores: " + e);
		}
		
		System.out.print("\nResultados");
		System.out.print("\nTotal: " + calc.soma(x, y));
		System.out.print("\nDiferença: " + calc.subtrai(x, y));
		System.out.print("\n" + (calc.divide(x, y) == 0 ? "Nao existe divisão por zero" : "Quociente" + calc.divide(x, y)));
		System.out.print("\nProduto: " + calc.multiplica(x, y));
		
		kb.close();
	}

}
