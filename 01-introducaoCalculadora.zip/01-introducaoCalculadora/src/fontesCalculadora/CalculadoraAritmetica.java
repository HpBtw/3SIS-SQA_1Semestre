package fontesCalculadora;

public class CalculadoraAritmetica {
	public double soma(double x, double y) {
		return x + y;
	}

	public double subtrai(double x, double y) {
		return x - y;
	}
	
	public double divide(double x, double y) {
		return (y == 0 ? 0 : x / y);
	}
	
	public double multiplica(double x, double y) {
		return x * y;
	}
}
